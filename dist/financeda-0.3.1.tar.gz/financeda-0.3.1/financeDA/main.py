# ##################################################
# financeda package 2.0
# Financial Data Analysis
# 金融数据分析
# Author: YeJunjie (Brice)
# E_Mail: ye@okwords.cn
# Date: 2025-12-20
# ####################################################
def hello_financeda():
    print("Hello from financial data analysis by okwords.cn!")

if __name__ == "__main__":
    hello_financeda()
